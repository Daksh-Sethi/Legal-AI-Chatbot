async function getAnswer() {
    const questionInput = document.getElementById("question");
    const responseContainer = document.getElementById("response-container");
    const answerElement = document.getElementById("answer");

    const question = questionInput.value.trim();

    if (!question) {
        alert("Please enter a question.");
        return;
    }

    answerElement.innerText = "Thinking...";
    responseContainer.style.display = "block";

    try {
        const response = await fetch("http://127.0.0.1:5000/answer", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ question }),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();

        if (result.answer) {
            answerElement.innerText = result.answer;
        } else {
            answerElement.innerText = `Error: ${result.error}`;
        }
    } catch (error) {
        console.error("Error fetching the answer:", error);
        answerElement.innerText = "Something went wrong. Please try again.";
    }
}
